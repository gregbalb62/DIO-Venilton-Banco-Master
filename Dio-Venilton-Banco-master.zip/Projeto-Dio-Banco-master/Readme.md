Pilares da Programa��o Orientada Objetos
Abstra��o: Habilidade de concentrar-se nos aspectos essenciais de um dominio, ignorando caracteristicas menos importantes ou acidentais.

Encapsulamento: significa esconder o implementa��o dos objetos, criando assim interfaces de uso mais concisas e f�ceis de usar entender. O encapsulamento favorece principalment dois aspectos de um sistema seriam manuten��o e a evolu��o.

Heran�a: Permite que voc� defina uma classe filha que reutilize (herda), estende ou modifica o comportamento de uma classi pai. A classe cujo membro s�o herdados � chamada de classe base; a classe que herda os membros da classe base � chamada de classe derivada.

Polimorfismo: Capacidade de um objeto pode ser referenciado de v�rias formas, ou seja, � capacidade de tratar objetos criados apartir das classes especificas como objetos de uma classe gen�rica.